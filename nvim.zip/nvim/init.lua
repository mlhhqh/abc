require("pkg.packages")
require("pkg.cmp")
require("pkg.ui")
require("pkg.dap")
require("pkg.lsp.main")
require("pkg.keybindings")
require("pkg.syntax")

vim.cmd("set nocursorcolumn")
require("neovide")

vim.g.mapleader = " "
require("which-key").setup({
	preset = "helix",
	win = {
		-- don't allow the popup to overlap with the cursor
		no_overlap = true,
		-- width = 1,
		-- height = { min = 4, max = 25 },
		-- col = 0,
		-- row = math.huge,
		border = "rounded",
		padding = { 1, 2 }, -- extra window padding [top/bottom, right/left]
		title = true,
		title_pos = "center",
		zindex = 1000,
		-- Additional vim.wo and vim.bo options
		bo = {},
		wo = {
			winblend = 50, -- value between 0-100 0 for fully opaque and 100 for fully transparent
		},
	},
})
vim.cmd([[set cmdheight=0]])
vim.cmd("colorscheme cyberdream")

-- fold
local function fold()
	vim.opt.foldmethod   = 'expr'
	vim.opt.foldexpr     = 'nvim_treesitter#foldexpr()'
	vim.o.foldcolumn     = '0'
	vim.o.foldlevel      = 99
	vim.o.foldlevelstart = 99
	vim.o.foldenable     = true

	vim.keymap.set("n", "yR", require("ufo").openAllFolds)
	vim.keymap.set("n", "yM", require("ufo").closeAllFolds)
	require("ufo").setup({
		enable_get_fold_virt_text = true,
		open_fold_hl_timeout = 100,
		provider_selector = function(_, _, _)
			return { "treesitter", "indent" }
		end,
		preview = {
			win_config = {
				border = "single",
				winblend = 10,
			},
		},
		fold_virt_text_handler = function(virtText, lnum, endLnum, width, _)
			local newVirtText = {}
			local suffix = (" %d  ..."):format(endLnum - lnum)
			local suffixWidth = vim.fn.strdisplaywidth(suffix)
			local targetWidth = width - suffixWidth
			local curWidth = 0
			for _, chunk in ipairs(virtText) do
				local chunkText = chunk[1]
				local chunkWidth = vim.fn.strdisplaywidth(chunkText)
				if curWidth + chunkWidth < targetWidth then
					table.insert(newVirtText, chunk)
				else
					chunkText = vim.fn.strcharpart(chunkText, 0, targetWidth - curWidth)
					local hlGroup = chunk[2]
					table.insert(newVirtText, { chunkText, hlGroup })
					chunkWidth = vim.fn.strdisplaywidth(chunkText)
					if curWidth + chunkWidth < targetWidth then
						if suffix then
							table.insert(newVirtText, { suffix, "MoreMsg" })
							return newVirtText
						end
						return newVirtText
					end
					curWidth = curWidth + chunkWidth
					break
				end
				curWidth = curWidth + chunkWidth
			end
			if suffix then
				table.insert(newVirtText, { suffix, "MoreMsg" })
			end
			return newVirtText
		end
	})
end

fold()

require('lspconfig').pyright.setup({})
function _G.get_node_type()
	local node = vim.treesitter.get_node()
	if node then
		print("Node type: " .. node:type())
	else
		print("No node found")
	end
end

-- Create command
vim.api.nvim_create_user_command("NodeType", "lua _G.get_node_type()", {})

require("mcphub").setup({
	use_bundled_binary = true,
	extensions = {
		avante = {
			make_slash_commands = true, -- make /slash commands from MCP server prompts
		}
	}
})

require("avante").setup({
	hints = {
		enabled = false,
		submit_hints = true,
	},
	-- system_prompt as function ensures LLM always has latest MCP server state
	-- This is evaluated for every message, even in existing chats
	system_prompt = function()
		local hub = require("mcphub").get_hub_instance()
		return hub and hub:get_active_servers_prompt() or ""
	end,
	-- Using function prevents requiring mcphub before it's loaded
	custom_tools = function()
		return {
			require("mcphub.extensions.avante").mcp_tool(),
		}
	end,
	provider = "llamacpp",
	providers = {
		ollama = {
			endpoint = "http://localhost:11434",
			model = "hf.co/unsloth/DeepSeek-R1-0528-Qwen3-8B-GGUF:Q2_K",
		},
		llamacpp = {
			__inherited_from = 'openai',
			endpoint = "http://127.0.0.1:8081",
			api_key_name = "test",
			model = "test",
		},
	}
})

-- require("pets").setup({})

-- require("neomodern").setup({
-- 	-- optional configuration here
-- })
-- require("neomodern").load()
-- Hydra for Tree-sitter navigation using nvim-treesitter-textobjects
-- Requires: nvim-treesitter-textobjects and hydra.nvim

require('ts-bg-highlight').setup({})

require("mypl")
