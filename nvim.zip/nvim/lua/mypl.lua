-- Tree-sitter navigation functions
local ts_utils = require('nvim-treesitter.ts_utils')
local ts_locals = require('nvim-treesitter.locals')

-- Helper functions for tree-sitter navigation
local M = {}

-- Get current node at cursor
local function get_current_node()
	return ts_utils.get_node_at_cursor()
end

-- Navigate to logical next node
M.navigate_logical_next = function()
	local node = get_current_node()
	if node then
		local next_node = ts_utils.get_next_node(node, true, true)
		if next_node then
			ts_utils.goto_node(next_node)
		end
	end
end

-- Navigate to logical previous node
M.navigate_logical_previous = function()
	local node = get_current_node()
	if node then
		local prev_node = ts_utils.get_previous_node(node, true, true)
		if prev_node then
			ts_utils.goto_node(prev_node)
		else
			-- Try to get parent
			local parent_node = ts_utils.get_root_for_node(node)
			if parent_node then
				ts_utils.goto_node(parent_node)
			end
		end
	end
end

-- Navigate up to parent node
M.navigate_up = function()
	local node = get_current_node()
	if node then
		local parent = node:parent()
		if parent then
			ts_utils.goto_node(parent)
		end
	end
end

-- Navigate to next sibling
M.navigate_next = function()
	local node = get_current_node()
	if node then
		local next_sibling = node:next_sibling()
		if next_sibling then
			ts_utils.goto_node(next_sibling)
		end
	end
end

-- Navigate to previous sibling
M.navigate_previous = function()
	local node = get_current_node()
	if node then
		local prev_sibling = node:prev_sibling()
		if prev_sibling then
			ts_utils.goto_node(prev_sibling)
		end
	end
end

-- M.navigate_down = function()
-- 	local node = get_current_node()
-- 	if node then
-- 		local child_count = node:child_count()
-- 		for i = 0, child_count - 1 do
-- 			local child = node:child(i)
-- 			if child and not child:type():match("^[%p%s]*$") then -- Skip punctuation/whitespace
-- 				ts_utils.goto_node(child)
-- 				return
-- 			end
-- 		end
-- 	end
-- end

M.navigate_down = function()
	local node = get_current_node()
	if node then
		ts_utils.goto_node(node:child(1))
	end
end

-- Navigate to beginning of function definition
M.navigate_beginning_of_defun = function()
	local node = get_current_node()
	if node then
		-- Find the nearest function node
		local function_node = node
		while function_node do
			local node_type = function_node:type()
			if node_type:match("function") or node_type:match("method") or node_type:match("defun") then
				ts_utils.goto_node(function_node)
				return
			end
			function_node = function_node:parent()
		end
	end
end

-- Hydra configuration
local Hydra = require('hydra')

local treesitter_hydra = Hydra({
	name = 'My Tree-sitter Navigation',
	mode = 'n',
	body = '<leader>m',
	hint = [[
 Tree-sitter Navigation
 _n_: logical next     _e_: logical previous
 _h_: up              _j_: next sibling
 _k_: previous        _l_: down
 _P_: start defun
 _q_: quit
]],
	config = {
		color = 'red',
		invoke_on_body = true,
		hint = {
			position = 'bottom',
			border = 'rounded'
		}
	},
	heads = {
		{ 'n',     M.navigate_logical_next,       { desc = 'logical next' } },
		{ 'e',     M.navigate_logical_previous,   { desc = 'logical previous' } },
		{ 'h',     M.navigate_up,                 { desc = 'up' } },
		{ 'j',     M.navigate_next,               { desc = 'next' } },
		{ 'k',     M.navigate_previous,           { desc = 'previous' } },
		{ 'l',     M.navigate_down,               { desc = 'down' } },
		{ 'P',     M.navigate_beginning_of_defun, { desc = 'start defun' } },
		{ 'q',     nil,                           { exit = true, desc = 'quit' } },
		{ '<Esc>', nil,                           { exit = true } },
	}
})

-- Which-key registration (optional but recommended)
local wk = require('which-key')
wk.register({
	m = {
		name = "My Tree-sitter Navigation",
		function() treesitter_hydra:activate() end,
		"Tree-sitter movement hydra"
	}
}, { prefix = "<leader>" })

-- Alternative: Direct key mappings without hydra (if you prefer)
--[[
local function setup_treesitter_keymaps()
  local opts = { noremap = true, silent = true }

  vim.keymap.set('n', '<leader>mn', M.navigate_logical_next, opts)
  vim.keymap.set('n', '<leader>me', M.navigate_logical_previous, opts)
  vim.keymap.set('n', '<leader>mh', M.navigate_up, opts)
  vim.keymap.set('n', '<leader>mj', M.navigate_next, opts)
  vim.keymap.set('n', '<leader>mk', M.navigate_previous, opts)
  vim.keymap.set('n', '<leader>ml', M.navigate_down, opts)
  vim.keymap.set('n', '<leader>mP', M.navigate_beginning_of_defun, opts)
end

-- Uncomment to use direct mappings instead of hydra
-- setup_treesitter_keymaps()
--]]

return M
