require("lspconfig").ts_ls.setup({})
require("lspconfig").svelte.setup({})
