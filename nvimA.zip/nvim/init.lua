require("pkg.packages")
require("pkg.cmp")
require("pkg.ui")
require("pkg.dap")
require("pkg.lsp.main")
require("pkg.keybindings")
require("pkg.syntax")

vim.cmd("set nocursorcolumn")
require("neovide")

vim.g.mapleader = " "
require("which-key").setup({
	preset = "helix",
	win = {
		-- don't allow the popup to overlap with the cursor
		no_overlap = true,
		-- width = 1,
		-- height = { min = 4, max = 25 },
		-- col = 0,
		-- row = math.huge,
		border = "rounded",
		padding = { 1, 2 }, -- extra window padding [top/bottom, right/left]
		title = true,
		title_pos = "center",
		zindex = 1000,
		-- Additional vim.wo and vim.bo options
		bo = {},
		wo = {
			winblend = 50, -- value between 0-100 0 for fully opaque and 100 for fully transparent
		},
	},
})
vim.cmd([[set cmdheight=0]])

-- fold
local function fold()
	vim.opt.foldmethod   = 'expr'
	vim.opt.foldexpr     = 'nvim_treesitter#foldexpr()'
	vim.o.foldcolumn     = '0'
	vim.o.foldlevel      = 99
	vim.o.foldlevelstart = 99
	vim.o.foldenable     = true

	vim.keymap.set("n", "yR", require("ufo").openAllFolds)
	vim.keymap.set("n", "yM", require("ufo").closeAllFolds)
	require("ufo").setup({
		enable_get_fold_virt_text = true,
		open_fold_hl_timeout = 100,
		provider_selector = function(_, _, _)
			return { "treesitter", "indent" }
		end,
		preview = {
			win_config = {
				border = "single",
				winblend = 10,
			},
		},
		fold_virt_text_handler = function(virtText, lnum, endLnum, width, _)
			local newVirtText = {}
			local suffix = (" %d  ..."):format(endLnum - lnum)
			local suffixWidth = vim.fn.strdisplaywidth(suffix)
			local targetWidth = width - suffixWidth
			local curWidth = 0
			for _, chunk in ipairs(virtText) do
				local chunkText = chunk[1]
				local chunkWidth = vim.fn.strdisplaywidth(chunkText)
				if curWidth + chunkWidth < targetWidth then
					table.insert(newVirtText, chunk)
				else
					chunkText = vim.fn.strcharpart(chunkText, 0, targetWidth - curWidth)
					local hlGroup = chunk[2]
					table.insert(newVirtText, { chunkText, hlGroup })
					chunkWidth = vim.fn.strdisplaywidth(chunkText)
					if curWidth + chunkWidth < targetWidth then
						if suffix then
							table.insert(newVirtText, { suffix, "MoreMsg" })
							return newVirtText
						end
						return newVirtText
					end
					curWidth = curWidth + chunkWidth
					break
				end
				curWidth = curWidth + chunkWidth
			end
			if suffix then
				table.insert(newVirtText, { suffix, "MoreMsg" })
			end
			return newVirtText
		end
	})
end

fold()

require('lspconfig').pyright.setup({})
function _G.get_node_type()
	local node = vim.treesitter.get_node()
	if node then
		print("Node type: " .. node:type())
	else
		print("No node found")
	end
end

-- Create command
vim.api.nvim_create_user_command("NodeType", "lua _G.get_node_type()", {})

require("mcphub").setup({
	use_bundled_binary = true,
	extensions = {
		avante = {
			make_slash_commands = true, -- make /slash commands from MCP server prompts
		}
	}
})
require("avante").setup({
	hints = {
		enabled = false,
		submit_hints = true,
	},
	-- system_prompt as function ensures LLM always has latest MCP server state
	-- This is evaluated for every message, even in existing chats
	system_prompt = function()
		local hub = require("mcphub").get_hub_instance()
		return hub and hub:get_active_servers_prompt() or ""
	end,
	-- Using function prevents requiring mcphub before it's loaded
	custom_tools = function()
		return {
			require("mcphub.extensions.avante").mcp_tool(),
		}
	end,
	provider = "llamacpp",
	providers = {
		ollama = {
			endpoint = "http://localhost:11434",
			model = "hf.co/unsloth/DeepSeek-R1-0528-Qwen3-8B-GGUF:Q2_K",
		},
		llamacpp = {
			__inherited_from = 'openai',
			endpoint = "http://127.0.0.1:8081",
			api_key_name = "test",
			model = "test",
		},
	}
})
--require("pets").setup({})
require("mypl").setup({ which_key = true, hydra = true })

-- Define a custom sign
vim.fn.sign_define('neon_marker', {
	text = '>',
	texthl = 'NeonLineMarker',
	numhl = ''
})

-- vim.fn.sign_define('neon_marker_plain', {
-- 	text = '>',
-- 	texthl = '',
-- 	numhl = ''
-- })

-- Define the highlight
vim.api.nvim_set_hl(0, 'NeonLineMarker', {
	fg = '#FF00FF',
	bold = false,
	italic = false,
	undercurl = false,
	sp = '#8A2BE2'
})
--
-- -- Auto-place signs every 5th line
-- --'TextChanged', 'TextChangedI', 'CursorMoved' }
-- vim.api.nvim_create_autocmd({ 'BufEnter', }, {
-- 	callback = function()
-- 		local buf = vim.api.nvim_get_current_buf()
-- 		local cursor_line = vim.api.nvim_win_get_cursor(0)[1]
-- 		local line_count = vim.api.nvim_buf_line_count(buf)
--
-- 		vim.fn.sign_unplace('neon_group', { buffer = buf })
--
-- 		-- Place actual cursor
-- 		vim.fn.sign_place(0, 'neon_group', 'neon_marker', buf, { lnum = cursor_line })
--
-- 		-- Place signs every 5 lines going down from cursor
-- 		for i = cursor_line + 5, line_count, 5 do
-- 			vim.fn.sign_place(0, 'neon_group', 'neon_marker_plain', buf, { lnum = i })
-- 		end
--
-- 		-- Place signs every 5 lines going up from cursor
-- 		for i = cursor_line - 5, 1, -5 do
-- 			vim.fn.sign_place(0, 'neon_group', 'neon_marker_plain', buf, { lnum = i })
-- 		end
-- 	end
-- })

vim.api.nvim_create_autocmd({ 'BufEnter', 'TextChanged', 'TextChangedI', 'CursorMoved' }, {
	callback = function()
		local buf = vim.api.nvim_get_current_buf()
		local cursor_line = vim.api.nvim_win_get_cursor(0)[1]
		vim.fn.sign_unplace('neon_group_cursor', { buffer = buf })
		vim.fn.sign_place(0, 'neon_group_cursor', 'neon_marker', buf, { lnum = cursor_line })
	end
})


-- require('ts-bg-highlight').setup({})
require("rainbow")
vim.opt.number = false
vim.opt.relativenumber = false
require("cyberdream").setup({
	variant = "default",
	transparent = false,
	hide_fillchars = false,
	borderless_pickers = false,
	cache = false
})
vim.cmd("colorscheme cyberdream")
vim.api.nvim_create_autocmd('LspAttach', {
	group = vim.api.nvim_create_augroup('DisableGoSemanticTokens', { clear = true }),
	callback = function(args)
		local client = vim.lsp.get_client_by_id(args.data.client_id)
		if client and client.name == 'gopls' then
			vim.api.nvim_set_hl(0, '@lsp.type.namespace.go', {})
			-- Add other go-specific tokens here
		end
	end,
})
require("flash").setup()
require('nvim-treeclimber').setup()
vim.opt.mouse = 'a'  -- Enable mouse in all modes
require("gosigns").setup({
	on_attach = function(bufnr)
		local gs = package.loaded.gitsigns
		vim.keymap.set('n', '<LeftMouse>', function()
			-- if vim.fn.getmousepos().wincol <= 2 then
				print("Hello world")
			-- end
		end, { buffer = bufnr })
	end
})
require("treesitter-context").setup({})
