local ts_utils = require('nvim-treesitter.ts_utils')
local parsers = require('nvim-treesitter.parsers')

local M = {}

-- Configuration - you can customize these node types per language
M.navigable_nodes = {
	default = {
		'function_declaration',
		'function_definition',
		'method_declaration',
		'method_definition',
		'class_declaration',
		'class_definition',
		'if_statement',
		'for_statement',
		'while_statement',
		'try_statement',
		'catch_clause',
		'variable_declaration',
		'assignment_expression',
		'call_expression',
		'return_statement',
	}
}

-- Get node at current cursor position
local function get_node_at_point(node_types, named_only)
	local node = ts_utils.get_node_at_cursor()
	if not node then return nil end

	named_only = named_only ~= false -- default to true

	if node_types then
		local current = node
		while current do
			local node_type = current:type()

			-- Check if current node matches our criteria
			if vim.tbl_contains(node_types, node_type) and (not named_only or current:named()) then
				return current
			end

			-- Check smallest descendant at this position
			local start_row, start_col = current:start()
			for child in current:iter_children() do
				local child_start_row, child_start_col = child:start()
				if child_start_row == start_row and child_start_col == start_col then
					if vim.tbl_contains(node_types, child:type()) and (not named_only or child:named()) then
						return child
					end
				end
			end

			current = current:parent()
		end
	end

	return node
end

-- Check if node starts after current cursor position
local function node_after_point_p(node)
	if not node then return false end

	local cursor = vim.api.nvim_win_get_cursor(0)
	local cursor_row, cursor_col = cursor[1] - 1, cursor[2] -- Convert to 0-indexed
	local node_row, node_col = node:start()

	return node_row > cursor_row or (node_row == cursor_row and node_col > cursor_col)
end

-- Check if node starts before current cursor position
local function node_before_point_p(node)
	if not node then return false end

	local cursor = vim.api.nvim_win_get_cursor(0)
	local cursor_row, cursor_col = cursor[1] - 1, cursor[2] -- Convert to 0-indexed
	local node_row, node_col = node:start()

	return node_row < cursor_row or (node_row == cursor_row and node_col < cursor_col)
end

-- Get all siblings of a node
local function get_siblings(node)
	if not node then return {} end

	local parent = node:parent()
	if not parent then return { node } end

	local siblings = {}
	for child in parent:iter_children() do
		table.insert(siblings, child)
	end

	return siblings
end

-- Get navigable nodes for current language
local function get_navigable_nodes()
	local bufnr = vim.api.nvim_get_current_buf()
	local parser = parsers.get_parser(bufnr)
	if not parser then return M.navigable_nodes.default end

	local lang = parser:lang()
	return M.navigable_nodes[lang] or M.navigable_nodes.default
end

-- Get nearest navigable node to cursor
local function get_nearest_navigable_node()
	return get_node_at_point(get_navigable_nodes())
end

-- Search for nodes in tree using predicate
local function tree_search(node, predicate, backward)
	if not node then return nil end

	local function search_in_tree(current_node, visited)
		if visited[current_node] then return nil end
		visited[current_node] = true

		-- Check current node
		if predicate(current_node) then
			return current_node
		end

		-- Search children
		if not backward then
			for child in current_node:iter_children() do
				local result = search_in_tree(child, visited)
				if result then return result end
			end
		end

		-- Search siblings
		local siblings = get_siblings(current_node)
		local start_idx = 1

		-- Find current node position in siblings
		for i, sibling in ipairs(siblings) do
			if sibling == current_node then
				start_idx = backward and (i - 1) or (i + 1)
				break
			end
		end

		local step = backward and -1 or 1
		local end_idx = backward and 1 or #siblings

		for i = start_idx, end_idx, step do
			if siblings[i] then
				local result = search_in_tree(siblings[i], visited)
				if result then return result end
			end
		end

		-- Search up to parent
		local parent = current_node:parent()
		if parent then
			return search_in_tree(parent, visited)
		end

		return nil
	end

	return search_in_tree(node, {})
end

-- Navigate to logical next node
function M.navigate_logical_next()
	local current_node = get_node_at_point()
	if not current_node then
		vim.notify("No node at cursor")
		return false
	end

	local next_node = tree_search(current_node, node_after_point_p, false)
	if next_node then
		ts_utils.goto_node(next_node)
		return true
	end

	vim.notify("No next logical node found")
	return false
end

-- Navigate to logical previous node
function M.navigate_logical_previous()
	local current_node = get_node_at_point()
	if not current_node then
		vim.notify("No node at cursor")
		return false
	end

	local prev_node = tree_search(current_node, node_before_point_p, true)
	if prev_node then
		ts_utils.goto_node(prev_node)
		return true
	end

	vim.notify("No previous logical node found")
	return false
end

-- Navigate up to parent
function M.navigate_up()
	local current_node = get_nearest_navigable_node()
	if not current_node then
		vim.notify("No navigable node at cursor")
		return false
	end

	local parent = current_node:parent()
	while parent do
		local navigable_nodes = get_navigable_nodes()
		if vim.tbl_contains(navigable_nodes, parent:type()) then
			-- Check if we're not already at the beginning of this node
			local cursor = vim.api.nvim_win_get_cursor(0)
			local cursor_row, cursor_col = cursor[1] - 1, cursor[2]
			local parent_row, parent_col = parent:start()

			if not (cursor_row == parent_row and cursor_col == parent_col) then
				ts_utils.goto_node(parent)
				return true
			end
		end
		parent = parent:parent()
	end

	vim.notify("No navigable parent found")
	return false
end

-- Navigate to next sibling
function M.navigate_next()
	local current_node = get_nearest_navigable_node()
	if not current_node then
		vim.notify("No navigable node at cursor")
		return false
	end

	local siblings = get_siblings(current_node)
	local navigable_nodes = get_navigable_nodes()

	-- Filter to only navigable siblings after current position
	local next_siblings = {}
	for _, sibling in ipairs(siblings) do
		if vim.tbl_contains(navigable_nodes, sibling:type()) and node_after_point_p(sibling) then
			table.insert(next_siblings, sibling)
		end
	end

	if #next_siblings > 0 then
		ts_utils.goto_node(next_siblings[1])
		return true
	end

	vim.notify("No next sibling found")
	return false
end

-- Navigate to previous sibling
function M.navigate_previous()
	local current_node = get_nearest_navigable_node()
	if not current_node then
		vim.notify("No navigable node at cursor")
		return false
	end

	local siblings = get_siblings(current_node)
	local navigable_nodes = get_navigable_nodes()

	-- Filter to only navigable siblings before current position
	local prev_siblings = {}
	for _, sibling in ipairs(siblings) do
		if vim.tbl_contains(navigable_nodes, sibling:type()) and node_before_point_p(sibling) then
			table.insert(prev_siblings, sibling)
		end
	end

	if #prev_siblings > 0 then
		-- Get the last (closest) previous sibling
		ts_utils.goto_node(prev_siblings[#prev_siblings])
		return true
	end

	vim.notify("No previous sibling found")
	return false
end

-- Navigate down to first child
function M.navigate_down()
	local current_node = get_nearest_navigable_node()
	if not current_node then
		vim.notify("No navigable node at cursor")
		return false
	end

	local navigable_nodes = get_navigable_nodes()

	-- Look for navigable children after current cursor position
	local children_after_point = {}
	for child in current_node:iter_children() do
		if vim.tbl_contains(navigable_nodes, child:type()) and node_after_point_p(child) then
			table.insert(children_after_point, child)
		end
	end

	if #children_after_point > 0 then
		ts_utils.goto_node(children_after_point[1])
		return true
	end

	vim.notify("No navigable child found")
	return false
end

-- Get keybind definitions for hydra/which-key integration
function M.get_keybinds()
	return {
		-- Linear navigation
		{ 'n', M.navigate_logical_next,     { desc = 'Navigate logical next' } },
		{ 'e', M.navigate_logical_previous, { desc = 'Navigate logical previous' } },

		-- Tree navigation (hjkl)
		{ 'h', M.navigate_up,               { desc = 'Navigate up' } },
		{ 'j', M.navigate_next,             { desc = 'Navigate next' } },
		{ 'k', M.navigate_previous,         { desc = 'Navigate previous' } },
		{ 'l', M.navigate_down,             { desc = 'Navigate down' } },
	}
end

-- Hydra integration
function M.create_hydra()
	local ok, hydra = pcall(require, 'hydra')
	if not ok then
		vim.notify('Hydra not available', vim.log.levels.ERROR)
		return
	end

	local keybinds = M.get_keybinds()
	local heads = {}

	for _, bind in ipairs(keybinds) do
		table.insert(heads, { bind[1], bind[2], bind[3] })
	end

	-- Add quit keys
	table.insert(heads, { 'q', nil, { exit = true, desc = 'Quit' } })
	table.insert(heads, { '<Esc>', nil, { exit = true, desc = 'Quit' } })

	return hydra({
		name = 'TreeSitter Navigation',
		mode = 'n',
		body = '<leader>t',
		hint = [[
 TreeSitter Navigation (Combobulate-style)

 Linear:    _n_: logical next    _e_: logical prev
 Tree:      _h_: up    _j_: next    _k_: prev    _l_: down

 _q_/_<Esc>_: quit
]],
		config = {
			color = 'pink',
			invoke_on_body = true,
			hint = {
				position = 'bottom',
				border = 'rounded'
			},
		},
		heads = heads
	})
end

-- Which-key integration
function M.setup_which_key()
	local ok, wk = pcall(require, 'which-key')
	if not ok then
		vim.notify('which-key not available', vim.log.levels.ERROR)
		return
	end

	local keybinds = M.get_keybinds()
	local mappings = {}

	for _, bind in ipairs(keybinds) do
		mappings[bind[1]] = { bind[2], bind[3].desc }
	end

	wk.register(mappings, {
		mode = 'n',
		prefix = '<leader>t',
		buffer = nil,
		silent = true,
		noremap = true,
		nowait = false,
	})

	-- Register the main trigger
	wk.register({
		t = {
			name = 'TreeSitter Navigation',
		}
	}, {
		mode = 'n',
		prefix = '<leader>',
	})
end

-- Direct keymap setup (fallback)
function M.setup_keymaps(prefix)
	prefix = prefix or '<leader>t'
	local opts = { noremap = true, silent = true }

	local keybinds = M.get_keybinds()

	for _, bind in ipairs(keybinds) do
		local key = prefix .. bind[1]
		local func = bind[2]
		local desc = bind[3].desc
		vim.keymap.set('n', key, func, vim.tbl_extend('force', opts, { desc = desc }))
	end
end

-- Main setup function
function M.setup(opts)
	opts = opts or {}

	if opts.hydra or opts.use_hydra then
		M.create_hydra()
	elseif opts.which_key or opts.use_which_key then
		M.setup_which_key()
	else
		M.setup_keymaps(opts.prefix)
	end
end

-- Allow customization of navigable nodes per language
function M.set_navigable_nodes(lang, nodes)
	M.navigable_nodes[lang] = nodes
end

return M
