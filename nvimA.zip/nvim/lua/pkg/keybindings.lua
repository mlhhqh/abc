vim.keymap.set("i", "jk", "<Esc>", nil)
vim.keymap.set('t', 'jk', '<C-\\><C-n>')
-- vim.api.nvim_set_keymap('n', 'ya', 'za', { noremap = true, silent = true })
-- vim.api.nvim_set_keymap('n', 'yA', 'zA', { noremap = true, silent = true })
