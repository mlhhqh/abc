local function bootstrap_pckr()
	local pckr_path = vim.fn.stdpath("data") .. "/pckr/pckr.nvim"

	if not (vim.uv or vim.loop).fs_stat(pckr_path) then
		vim.fn.system({
			'git',
			'clone',
			"--filter=blob:none",
			'https://github.com/lewis6991/pckr.nvim',
			pckr_path
		})
	end

	vim.opt.rtp:prepend(pckr_path)
end

bootstrap_pckr()

require('pckr').add {
	{ "LintaoAmons/bookmarks.nvim" },
	{ "bassamsdata/namu.nvim" },
	{ "nvim-telescope/telescope.nvim" },
	{ "FabianWirth/search.nvim" },
	{ "RRethy/nvim-treesitter-textsubjects" },
	{ "milanglacier/minuet-ai.nvim" },
	{ "maxandron/goplements.nvim" },
	{ "nvim-treesitter/nvim-treesitter-textobjects" },
	{ "romgrk/barbar.nvim" },
	{ "ray-x/navigator.lua" },
	{ "jubnzv/virtual-types.nvim" },
	{ "ray-x/lsp_signature.nvim" },
	{ "hedyhli/outline.nvim" },
	{ "marilari88/twoslash-queries.nvim" },
	{ "b0o/SchemaStore.nvim" },
	{ "VidocqH/lsp-lens.nvim" },
	{ "mawkler/refjump.nvim" },
	{ "nvim-treesitter/nvim-treesitter-context" },
	{ "Yu-Leo/gosigns.nvim" },
	{ "Dkendal/nvim-treeclimber" },
	{ "folke/flash.nvim" },
	{ "lewis6991/gitsigns.nvim" },
	{ "NeogitOrg/neogit" },
	{ "00sapo/visual.nvim" },
	{ "scottmckendry/cyberdream.nvim" },
	{ "folke/twilight.nvim" },
	{ "nvim-tree/nvim-web-devicons" },
	{ "Dkendal/nvim-treeclimber" },
	{ "nvimtools/hydra.nvim" },
	{ "rktjmp/lush.nvim" },
	{ "cdmill/neomodern.nvim" },
	{ "felipeagc/fleet-theme-nvim" },
	{ "edluffy/hologram.nvim" },
	{ "giusgad/pets.nvim" },
	{ "yetone/avante.nvim", }, -- TODO: Build script (build = "bundled_build.lua")
	{ "ravitemer/mcphub.nvim" },
	{ "kamwitsta/flatwhite-vim" },
	{ "folke/trouble.nvim",               requires = { "nvim-lua/plenary.nvim" } },
	{ "folke/tokyonight.nvim",            as = "tokyonight" },
	{ "folke/which-key.nvim",             as = "which-key" },
	{ "navarasu/onedark.nvim",            as = "onedark" },
	{ "olimorris/onedarkpro.nvim",        as = "onedarkpro" },
	{ "mofiqul/vscode.nvim",              as = "vscode" },
	{ "rmehri01/onenord.nvim",            as = "onenord" },
	{ "aktersnurra/no-clown-fiesta.nvim", as = "no-clown-fiesta" },
	{ "ray-x/aurora", },
	{ "ntbbloodbath/doom-one.nvim",       as = "doom-one" },
	{ "nyoom-engineering/oxocarbon.nvim", as = "oxocarbon" },
	{ 'kevinhwang91/nvim-ufo',            requires = 'kevinhwang91/promise-async' },
	{ "nvim-neo-tree/neo-tree.nvim",      requires = { "nvim-lua/plenary.nvim", "nvim-tree/nvim-web-devicons", "MunifTanjim/nui.nvim" } },
	-- { "https://git.sr.ht/~whynothugo/lsp_lines.nvim" },
	{ "vague2k/vague.nvim", },
	{ "rcarriga/nvim-dap-ui",             requires = { "mfussenegger/nvim-dap", "nvim-neotest/nvim-nio", "leoluz/nvim-dap-go", "rcarriga/cmp-dap", "theHamsta/nvim-dap-virtual-text", "LiadOz/nvim-dap-repl-highlights" } },
	{ "ggml-org/llama.vim" },
	{ "folke/lazydev.nvim" },
	{ "MysticalDevil/inlay-hints.nvim" },
	{ 'nvim-treesitter/nvim-treesitter',
		run = function()
			local ts_update = require('nvim-treesitter.install').update({ with_sync = true })
			ts_update()
		end, },
	{ "luukvbaal/statuscol.nvim" },
	{ "catppuccin/nvim",         as = "catppuccin",                        name = "catppuccin" },
	{ "ibhagwan/fzf-lua",        requires = "nvim-tree/nvim-web-devicons", dependencies = "nvim-tree/nvim-web-devicons", },
	{ 'navarasu/onedark.nvim' },
	{ "neovim/nvim-lspconfig" },
	{ 'neovim/nvim-lspconfig' },
	{ 'hrsh7th/cmp-nvim-lsp' },
	{ 'hrsh7th/cmp-buffer' },
	{ 'hrsh7th/cmp-path' },
	{ 'hrsh7th/cmp-cmdline' },
	{ 'hrsh7th/nvim-cmp' },
	{ 'L3MON4D3/LuaSnip' },
}

vim.keymap.set('v', '<leader>x', ':lua<cr>', { desc = 'Execute selection' })
