require('nvim-treesitter.configs').setup {
	-- A list of parser names, or "all" (the listed parsers MUST always be installed)
	ensure_installed = { "lua", "bash", "markdown", "markdown_inline" },
	sync_install = true,
	auto_install = true,
	highlight = {
		enable = true,
		disable = function(lang, buf)
			local max_filesize = 10000 * 1024 -- 10000 KB
			local ok, stats = pcall(vim.loop.fs_stat, vim.api.nvim_buf_get_name(buf))
			if ok and stats and stats.size > max_filesize then
				return true
			end
		end,
		incremental_selection = {
			enable = true,
			keymaps = {
				init_selection = "<BS>",
				node_incremental = "<BS>",
				scope_incremental = "<C-H>", -- <C-BS> reads as <C-H> (in WezTerm, at least)
				node_decremental = "<M-BS>",
			},
		},
		additional_vim_regex_highlighting = false,
	},
	ignore_install = {},
	modules = {}
}

require("luasnip").setup()
vim.opt.foldmethod = 'expr'
vim.opt.foldexpr   = 'nvim_treesitter#foldexpr()'
