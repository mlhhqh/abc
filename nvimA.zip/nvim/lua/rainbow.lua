-- Add this to your init.lua or a separate config file

-- Define distinct but pleasant pastel rainbow colors for variables
local rainbow_colors = {
  "#E8F5E8", -- Light green
  "#FFF2CC", -- Light yellow
  "#E1F5FE", -- Light cyan
  "#FCE4EC", -- Light pink
  "#F3E5F5", -- Light purple
  "#FFF3E0", -- Light orange
  "#E0F2F1", -- Light teal
  "#FFEBEE", -- Light red
  "#E8EAF6", -- Light indigo
  "#F1F8E9", -- Light lime
}

-- Create a dedicated namespace for rainbow variables
local rainbow_ns = vim.api.nvim_create_namespace("rainbow_variables")

-- Configuration for highlighting mode
local config = {
  mode = "background", -- "background" or "foreground"
}

-- Function to determine if we should use white or black text based on background brightness
local function get_text_color(bg_color)
  -- Remove # if present
  bg_color = bg_color:gsub("#", "")
  
  -- Convert hex to RGB
  local r = tonumber(bg_color:sub(1, 2), 16) or 0
  local g = tonumber(bg_color:sub(3, 4), 16) or 0
  local b = tonumber(bg_color:sub(5, 6), 16) or 0
  
  -- Calculate luminance (0.299*R + 0.587*G + 0.114*B)
  local luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
  
  -- Use black text for light backgrounds, but make it slightly darker for better contrast
  return luminance > 0.5 and "#1a1a1a" or "#ffffff"
end

-- Function to create highlight groups based on current mode
local function create_highlight_groups()
  for i, color in ipairs(rainbow_colors) do
    if config.mode == "background" then
      local fg_color = get_text_color(color)
      -- Add bold text for better visibility, especially for short variables
      vim.api.nvim_set_hl(0, "RainbowVar" .. i, { bg = color, fg = fg_color, bold = true })
    else -- foreground mode
      -- Use darker, more saturated colors for foreground mode
      local fg_colors = {
        "#2E7D32", -- Dark green
        "#F57C00", -- Dark orange
        "#0277BD", -- Dark blue
        "#C2185B", -- Dark pink
        "#7B1FA2", -- Dark purple
        "#FF6F00", -- Dark amber
        "#00695C", -- Dark teal
        "#D32F2F", -- Dark red
        "#303F9F", -- Dark indigo
        "#689F38", -- Dark lime
      }
      vim.api.nvim_set_hl(0, "RainbowVar" .. i, { fg = fg_colors[i], bold = true })
    end
  end
end

-- Initialize highlight groups
create_highlight_groups()

-- Table to store variable name to color mappings per buffer
local buffer_var_colors = {}

-- Function to get or assign a color to a variable for a specific buffer
local function get_var_color(bufnr, var_name)
  if not buffer_var_colors[bufnr] then
    buffer_var_colors[bufnr] = { colors = {}, index = 1 }
  end
  
  local buf_data = buffer_var_colors[bufnr]
  if not buf_data.colors[var_name] then
    buf_data.colors[var_name] = buf_data.index
    buf_data.index = buf_data.index % #rainbow_colors + 1
  end
  return buf_data.colors[var_name]
end

-- Function to check if token should be highlighted
local function should_highlight_token(token_type_name, token_modifiers, legend)
  -- Only highlight variables, parameters, and struct fields
  if token_type_name == "variable" or token_type_name == "parameter" then
    return true
  end
  
  -- Check for struct fields (property type)
  if token_type_name == "property" then
    return true
  end
  
  return false
end

-- Function to apply rainbow coloring
local function apply_rainbow_colors(bufnr)
  -- Get LSP client for gopls
  local clients = vim.lsp.get_clients({ bufnr = bufnr, name = "gopls" })
  if #clients == 0 then
    return
  end
  
  local client = clients[1]
  
  -- Check if semantic tokens are supported
  if not client.server_capabilities.semanticTokensProvider then
    return
  end
  
  -- Request semantic tokens
  local params = {
    textDocument = vim.lsp.util.make_text_document_params(bufnr)
  }
  
  client.request("textDocument/semanticTokens/full", params, function(err, result)
    if err or not result then
      return
    end
    
    -- Clear only our rainbow highlights
    vim.api.nvim_buf_clear_namespace(bufnr, rainbow_ns, 0, -1)
    
    -- Parse semantic tokens
    local lines = vim.api.nvim_buf_get_lines(bufnr, 0, -1, false)
    local tokens = result.data
    local legend = client.server_capabilities.semanticTokensProvider.legend
    
    local line = 0
    local col = 0
    
    for i = 1, #tokens, 5 do
      local delta_line = tokens[i]
      local delta_col = tokens[i + 1]
      local length = tokens[i + 2]
      local token_type = tokens[i + 3]
      local token_modifiers = tokens[i + 4]
      
      line = line + delta_line
      if delta_line > 0 then
        col = delta_col
      else
        col = col + delta_col
      end
      
      -- Check if this token should be highlighted
      local token_type_name = legend.tokenTypes[token_type + 1]
      if should_highlight_token(token_type_name, token_modifiers, legend) then
        -- Get the variable name
        local line_text = lines[line + 1]
        if line_text then
          local var_name = line_text:sub(col + 1, col + length)
          
          -- Get color for this variable
          local color_num = get_var_color(bufnr, var_name)
          local hl_group = "RainbowVar" .. color_num
          
          -- Apply highlight
          local hl_mode = config.mode == "background" and "replace" or "combine"
          vim.api.nvim_buf_set_extmark(bufnr, rainbow_ns, line, col, {
            end_col = col + length,
            hl_group = hl_group,
            priority = 150,
            hl_mode = hl_mode
          })
        end
      end
    end
  end)
end

-- Clean up buffer data when buffer is deleted
local function cleanup_buffer(bufnr)
  buffer_var_colors[bufnr] = nil
end

-- Function to toggle between background and foreground modes
local function toggle_highlight_mode()
  config.mode = config.mode == "background" and "foreground" or "background"
  
  -- Recreate highlight groups
  create_highlight_groups()
  
  -- Reapply highlighting to all Go buffers
  for _, bufnr in ipairs(vim.api.nvim_list_bufs()) do
    if vim.api.nvim_buf_is_loaded(bufnr) then
      local ft = vim.api.nvim_buf_get_option(bufnr, "filetype")
      if ft == "go" then
        apply_rainbow_colors(bufnr)
      end
    end
  end
  
  print("Rainbow mode switched to: " .. config.mode)
end

-- Set up autocommands to trigger rainbow coloring
local rainbow_group = vim.api.nvim_create_augroup("RainbowVariables", { clear = true })

vim.api.nvim_create_autocmd({ "LspAttach" }, {
  group = rainbow_group,
  callback = function(args)
    local client = vim.lsp.get_client_by_id(args.data.client_id)
    if client and client.name == "gopls" then
      -- Only apply to Go files
      local ft = vim.api.nvim_buf_get_option(args.buf, "filetype")
      if ft ~= "go" then
        return
      end
      
      -- Enable semantic tokens and apply initial coloring
      if client.server_capabilities.semanticTokensProvider then
        -- Initial application
        vim.defer_fn(function()
          apply_rainbow_colors(args.buf)
        end, 100)
        
        -- Reapply colors on text changes (debounced)
        local timer = nil
        vim.api.nvim_create_autocmd({ "TextChanged", "TextChangedI" }, {
          group = rainbow_group,
          buffer = args.buf,
          callback = function()
            if timer then
              timer:stop()
            end
            timer = vim.defer_fn(function()
              apply_rainbow_colors(args.buf)
              timer = nil
            end, 300)
          end,
        })
        
        -- Also reapply on cursor hold for better responsiveness
        vim.api.nvim_create_autocmd("CursorHold", {
          group = rainbow_group,
          buffer = args.buf,
          callback = function()
            apply_rainbow_colors(args.buf)
          end,
        })
        
        -- Clean up when buffer is deleted
        vim.api.nvim_create_autocmd("BufDelete", {
          group = rainbow_group,
          buffer = args.buf,
          callback = function()
            cleanup_buffer(args.buf)
          end,
        })
      end
    end
  end,
})

-- Manual commands
vim.api.nvim_create_user_command("RainbowRefresh", function()
  apply_rainbow_colors(vim.api.nvim_get_current_buf())
end, { desc = "Refresh rainbow variable colors" })

vim.api.nvim_create_user_command("RainbowToggle", function()
  local bufnr = vim.api.nvim_get_current_buf()
  local marks = vim.api.nvim_buf_get_extmarks(bufnr, rainbow_ns, 0, -1, {})
  
  if #marks > 0 then
    -- Clear rainbow colors
    vim.api.nvim_buf_clear_namespace(bufnr, rainbow_ns, 0, -1)
    print("Rainbow variables disabled")
  else
    -- Apply rainbow colors
    apply_rainbow_colors(bufnr)
    print("Rainbow variables enabled")
  end
end, { desc = "Toggle rainbow variable colors on/off" })

vim.api.nvim_create_user_command("RainbowMode", function()
  toggle_highlight_mode()
end, { desc = "Toggle between background and foreground highlighting" })

vim.api.nvim_create_user_command("RainbowClear", function()
  local bufnr = vim.api.nvim_get_current_buf()
  vim.api.nvim_buf_clear_namespace(bufnr, rainbow_ns, 0, -1)
  cleanup_buffer(bufnr)
  print("Rainbow variables cleared")
end, { desc = "Clear rainbow variable colors and reset color assignments" })

-- Show current mode
vim.api.nvim_create_user_command("RainbowStatus", function()
  print("Rainbow highlighting mode: " .. config.mode)
end, { desc = "Show current rainbow highlighting mode" })
