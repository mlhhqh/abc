-- Save as: ~/.config/nvim/lua/ts-bg-highlight.lua
-- Load with: require('ts-bg-highlight').setup() or require('ts-bg-highlight').setup({colors = {...}})

local M = {}
local overlays = {}

-- Default colors (customizable)
local colors = {
  keyword = "#3d2a5e",    -- purple
  variable = "#2a3d5e",   -- blue
  string = "#2a5e3d",     -- green
}

-- Node types (exact matches only)
local node_types = {
  keyword = {"if", "else", "for", "while", "switch", "case", "default", "defer", "go",
             "select", "return", "break", "continue", "fallthrough", "goto", "range",
             "func", "var", "const", "type", "struct", "interface", "package", "import"},
  variable = {"identifier", "parameter_declaration"},
  string = {"interpreted_string_literal", "raw_string_literal", "rune_literal"},
}

-- Setup highlight groups
local function setup_highlights()
  vim.api.nvim_set_hl(0, "TSBgKeyword", {bg = colors.keyword})
  vim.api.nvim_set_hl(0, "TSBgVariable", {bg = colors.variable})
  vim.api.nvim_set_hl(0, "TSBgString", {bg = colors.string})
end

-- Clear overlays
local function clear_overlays()
  for _, overlay in ipairs(overlays) do
    pcall(vim.api.nvim_buf_del_extmark, overlay.buf, overlay.ns, overlay.id)
  end
  overlays = {}
end

-- Highlight buffer
local function highlight()
  local buf = vim.api.nvim_get_current_buf()
  
  -- Check if treesitter parser exists for this buffer
  local ok, parser = pcall(vim.treesitter.get_parser, buf)
  if not ok or not parser then return end
  
  local ok2, trees = pcall(parser.parse, parser)
  if not ok2 or not trees or #trees == 0 then return end
  
  local tree = trees[1]
  if not tree then return end
  
  clear_overlays()
  local ns = vim.api.nvim_create_namespace("ts_bg")
  
  local function traverse(node)
    local type = node:type()
    local hl_group = nil
    
    -- Exact matching for node types
    for category, types in pairs(node_types) do
      for _, t in ipairs(types) do
        if type == t then
          if category == "keyword" then
            hl_group = "TSBgKeyword"
          elseif category == "variable" then
            hl_group = "TSBgVariable"
          elseif category == "string" then
            hl_group = "TSBgString"
          end
          break
        end
      end
      if hl_group then break end
    end
    
    -- Create highlight
    if hl_group then
      local sr, sc, er, ec = node:range()
      local id = vim.api.nvim_buf_set_extmark(buf, ns, sr, sc, {
        end_row = er, end_col = ec, hl_group = hl_group
      })
      table.insert(overlays, {buf = buf, ns = ns, id = id})
    end
    
    -- Traverse children
    for child in node:iter_children() do
      traverse(child)
    end
  end
  
  traverse(tree:root())
end

-- Commands
vim.api.nvim_create_user_command("TSBgToggle", function()
  if #overlays > 0 then clear_overlays() else highlight() end
end, {})

-- Setup function
function M.setup(opts)
  opts = opts or {}
  
  -- Merge custom colors
  if opts.colors then
    colors = vim.tbl_extend("force", colors, opts.colors)
  end
  
  -- Setup highlights with custom colors
  setup_highlights()
  
  -- Auto-update only for buffers with treesitter
  vim.api.nvim_create_autocmd({"TextChanged", "TextChangedI", "BufEnter"}, {
    callback = function() vim.defer_fn(highlight, 50) end
  })
  
  -- Initial highlight
  highlight()
end

-- Auto-setup if called without setup() for backwards compatibility
if not M._setup_called then
  setup_highlights()
  vim.api.nvim_create_autocmd({"TextChanged", "TextChangedI", "BufEnter"}, {
    callback = function() vim.defer_fn(highlight, 50) end
  })
  highlight()
end

return M
